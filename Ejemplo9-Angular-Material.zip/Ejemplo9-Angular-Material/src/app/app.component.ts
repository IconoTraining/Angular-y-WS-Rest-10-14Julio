import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  estadoCivil = ['Soltero', 'Casado', 'Viudo', 'Divorciado', 'Pareja de Hecho'];

  nombres = [
    {nombre: 'Juan', color: 'yellow'},
    {nombre: 'Maria', color: 'orange'},
    {nombre: 'Pedro', color: 'blue'},
    {nombre: 'Laura', color: 'pink'},
    {nombre: 'Gonzalo', color: 'green'},
    {nombre: 'Sara', color: 'silver'}
  ]

}
