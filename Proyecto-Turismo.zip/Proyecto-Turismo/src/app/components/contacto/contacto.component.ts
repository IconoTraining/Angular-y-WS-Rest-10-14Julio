import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Component } from '@angular/core';

@Component({
  selector: 'app-contacto',
  templateUrl: './contacto.component.html',
  styleUrls: ['./contacto.component.css']
})
export class ContactoComponent {

  contactoForm = new FormGroup({
    nombre: new FormControl('', [Validators.required, Validators.minLength(3)]),
    telefono: new FormControl('', Validators.pattern('[6-7]{1}[0-9]{8}')),
    email: new FormControl('', Validators.email),
    asunto: new FormControl('', Validators.maxLength(20)),
    mensaje: new FormControl('', [Validators.required, Validators.minLength(20)]),
  });

  public get nombre(){
    return this.contactoForm.get('nombre');
  }

  public get telefono(){
    return this.contactoForm.get('telefono');
  }

  public get email(){
    return this.contactoForm.get('email');
  }

  public get asunto(){
    return this.contactoForm.get('asunto');
  }

  public get mensaje(){
    return this.contactoForm.get('mensaje');
  }
  
  enviar(){
    // Mostrar en la consola los datos del formulario
    console.log(this.contactoForm.value);
    alert("Nos pondremos en contacto con usted, lo antes posible");
  }


}
