import { MuseosService } from './../../services/museos.service';
import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { Museo } from 'src/app/models/museo';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';


@Component({
  selector: 'app-museos',
  templateUrl: './museos.component.html',
  styleUrls: ['./museos.component.css']
})
export class MuseosComponent implements AfterViewInit{

  museos: Museo[] = [];
  dataSource: any;
  nombreColumnas = ['nombre', 'abierto', 'horario', 'precio'];
  dato: string = '';

  @ViewChild(MatSort)
  sort: MatSort | undefined;

  @ViewChild(MatPaginator)
  paginator: MatPaginator | undefined;

  constructor(private museosService: MuseosService){
    this.museos = this.museosService.getAll();
    this.dataSource = new MatTableDataSource(this.museos);
  }

  filtrar(){
    this.dataSource.filter = this.dato;
  }

  ngAfterViewInit(): void {
    // Inicializar el sort
    if (this.sort != undefined){
      this.dataSource.sort = this.sort;
    }

    // Inicializar el paginador
    if (this.paginator != undefined){
      this.dataSource.paginator = this.paginator;
    }
  }

}
