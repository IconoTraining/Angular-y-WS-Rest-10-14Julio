import { MuseosService } from './../../services/museos.service';
import { ActivatedRoute } from '@angular/router';
import { Museo } from './../../models/museo';
import { Component } from '@angular/core';

@Component({
  selector: 'app-museo-detalle',
  templateUrl: './museo-detalle.component.html',
  styleUrls: ['./museo-detalle.component.css']
})
export class MuseoDetalleComponent {

  id: number = 0;
  museo?: Museo;
  
  constructor(private ruta: ActivatedRoute, private museosService: MuseosService){
    this.id = this.ruta.snapshot.params['codigo'];
    this.museo = this.museosService.buscarMuseo(this.id);
  }

}
