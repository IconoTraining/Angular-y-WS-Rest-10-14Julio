import { HttpClientModule } from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { MuseoDetalleComponent } from './components/museo-detalle/museo-detalle.component';
import { MuseosComponent } from './components/museos/museos.component';
import { EquipoComponent } from './components/equipo/equipo.component';

const misRutas: Routes = [
  {path: 'museos', component: MuseosComponent},
  {path: 'museo_detalle/:codigo', component: MuseoDetalleComponent},
  {path: 'equipo', component: EquipoComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    NavbarComponent,
    MuseoDetalleComponent,
    MuseosComponent,
    EquipoComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(misRutas),
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
