import { Directive, HostBinding, HostListener } from '@angular/core';

@Directive({
  selector: '[appContarClicks]'
})
export class ContarClicksDirective {

  numeroClicks: number = 0;

  // HostBinding modificamos el css del alemento
  @HostBinding('style.fontSize')  // tambien funciona font-size
  size: string = '';

  @HostBinding('style.opacity')
  opacidad: number = 0;

  constructor() { }


  // HostListener escuchamos los eventos
  @HostListener('click')
  onClick(){
    this.numeroClicks++;
    //alert(this.numeroClicks);
    this.size = (20 + this.numeroClicks + "px");
    this.opacidad += 0.1;
  }

}
