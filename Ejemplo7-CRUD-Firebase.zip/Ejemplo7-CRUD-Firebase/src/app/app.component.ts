import { AgendaService } from './services/agenda.service';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{

  contactos: any = [];
  id: string = '';
  codigo: string = '';
  amigo: any;
  mostrar:boolean = false;

  amigoForm = new FormGroup({
    nombre: new FormControl('', Validators.minLength(3)),
    telefono: new FormControl('', 
      [Validators.required, Validators.pattern('[6-7]{1}[0-9]{8}')])
  });

  constructor(private agendaService: AgendaService){}

  public get nombre(){
    return this.amigoForm.get('nombre');
  }

  public get telefono(){
    return this.amigoForm.get('telefono');
  }

  buscar(){
    this.agendaService.buscarAmigo(this.id).subscribe( (item) => {
      this.amigo = item.payload.data();
    });
  }

  buscarParaModificar(){
    this.agendaService.buscarAmigo(this.codigo).subscribe( (item) => {
      this.amigo = item.payload.data();
      this.amigoForm.setValue({
        nombre: this.amigo.nombre,
        telefono: this.amigo.telefono
      });

      // Tambien funciona:
      //this.amigoForm.setValue(item.payload.data());
      
      this.mostrar = true;
    });
  }

  cambios(){
    this.agendaService.modificarAmigo(this.codigo, this.amigoForm.value)
      .then( () => {
        alert("Contacto modificado correctamente");
        // limpiar el formulario
        this.amigoForm.reset();
        this.mostrar = false;
        this.amigo = null;
        this.codigo = '';
      })
      .catch( (error) => {
        console.log(error)
      });
  }

  alta(){
    console.log(this.amigoForm.value);
    this.agendaService.nuevoAmigo(this.amigoForm.value)
      .then( () => {
        alert("Contacto agregado correctamente");
        // limpiar el formulario
        this.amigoForm.reset();
      })
      .catch( (error) => {
        console.log(error)
      });
  }

  borrar(){
    this.agendaService.eliminarAmigo(this.id)
      .then(() => {
        alert("Contacto eliminado correctamente");
        this.id = '';
      })
      .catch( (error) => {
        console.log(error)
      });
  }

  ngOnInit(): void {
      this.agendaService.todosAmigos().subscribe( (datos) => {

        // limpio el array de contactos
        this.contactos = [];

        datos.forEach(element => {
          this.contactos.push(element.payload.doc.data());
        });
        
      } );
  }
}
