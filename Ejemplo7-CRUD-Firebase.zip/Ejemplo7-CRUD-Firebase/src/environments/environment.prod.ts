export const environment = {
  production: true,
  firebaseConfig:{
    apiKey: "AIzaSyCFM2HySx-pQ4Zx22zv5UT9S688Gxj2zjM",
        authDomain: "indra-anabel.firebaseapp.com",
        projectId: "indra-anabel",
        storageBucket: "indra-anabel.appspot.com",
        messagingSenderId: "89381622287",
        appId: "1:89381622287:web:4d4a3922dc86871d2cc97a"
  }
};
