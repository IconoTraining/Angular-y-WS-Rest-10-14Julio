// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyCFM2HySx-pQ4Zx22zv5UT9S688Gxj2zjM",
        authDomain: "indra-anabel.firebaseapp.com",
        projectId: "indra-anabel",
        storageBucket: "indra-anabel.appspot.com",
        messagingSenderId: "89381622287",
        appId: "1:89381622287:web:4d4a3922dc86871d2cc97a"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
